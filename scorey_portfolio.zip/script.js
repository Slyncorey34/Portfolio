$(document).ready(
	function(){
	$("#nav-bar").animate(
		opacity: ".5",
		}3000);

);
